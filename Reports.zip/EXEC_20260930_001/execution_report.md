# Execution backtest - frozen engines

stage_e_execution v1 | declaration 5ba73cc0687eb482 | D = STAGED_20260928_001, ENS = STAGEDXE_20260929_001 | ETFs by the name rule (no bhavcopy given)

**Read this first.** The PRIMARY setup was fixed before this ran. Every grid below is descriptive: choosing its best row would be fitting the backtest. This is the same history the engines were judged on - the forward paper ledger is the only new evidence.

## 1. The primary setup: D, 3 a day, hold 5 sessions, 1/15 of equity each, Rs 10 lakh, Zerodha costs

| CAGR | total | vol | Sharpe | Sortino | max drawdown | longest underwater | Calmar | final equity |
|---|---|---|---|---|---|---|---|---|
| +43.3% | +1008% | +30.3% | 1.35 | 1.88 | -47.6% | 201 sessions | 0.91 | Rs 11,076,105 |

Bootstrap range (block 10, 2,000 resamples): CAGR +15.2% to +79.3% (median +44.6%); max drawdown -58.8% to -25.5%.

Benchmarks: buying the whole eligible universe equal-weight (no costs) +22.2% CAGR, max drawdown -43.1%; random picks with identical mechanics -12.3% CAGR on average (range -15.8% to -6.6%).

## 2. Calendar

By year: 2020 +45.2%; 2021 +75.9%; 2022 +30.0%; 2023 +30.7%; 2024 +116.1%; 2025 +5.7%; 2026 +11.8%

- since 2024: CAGR +41.0%, max drawdown -33.0%, Sharpe 1.29
- since 2025-03-05: CAGR +29.6%, max drawdown -23.1%, Sharpe 1.08

Worst day -10.9%, worst week -16.0%, worst month -31.4%, best month +35.2%; 69% of months positive; longest losing streak 9 sessions.

Monthly returns (%):

| year | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 2020 | -1.3 | -9.8 | -31.4 | +30.7 | -5.7 | +35.2 | +6.9 | +6.1 | +2.9 | +7.8 | +8.3 | +4.6 |
| 2021 | -2.1 | +2.6 | +5.5 | +16.0 | +13.4 | +5.3 | +2.3 | -2.8 | +9.1 | -4.4 | -0.5 | +16.2 |
| 2022 | -3.6 | -3.9 | +12.0 | +4.7 | -10.4 | -5.7 | +6.1 | +4.5 | +1.5 | +9.9 | +7.9 | +5.9 |
| 2023 | -2.7 | -6.0 | +10.7 | +7.9 | +2.5 | +1.9 | -3.4 | +3.4 | +5.1 | +2.0 | +6.4 | +0.5 |
| 2024 | +15.2 | +7.2 | -2.4 | +13.9 | -1.9 | +11.0 | +9.1 | +5.8 | +12.1 | +1.7 | +9.2 | +0.6 |
| 2025 | -9.4 | -15.4 | +0.5 | +7.6 | +10.5 | +2.0 | +4.2 | -2.7 | +7.1 | -0.8 | +4.1 | +0.7 |
| 2026 | -4.9 | -1.0 | -14.2 | +13.5 | +5.4 | +6.3 | +5.5 | +6.6 | -3.2 |  |  |  |

## 3. Trades

4,965 trades; win rate 49.7%; average +81.5 bp, median -2.6 bp; average win +695.6 bp, average loss -526.5 bp, payoff 1.32; 5th / 95th percentile -1205 / +1599 bp. The best 5% of trades carry 201% of the profit. Locked exits 167 (average -1088 bp); orders capped by liquidity 433.

Per-trade net by watchlist rank (35 bp, honest exits, no capital effects):

| rank | trades | mean bp | median bp |
|---|---|---|---|
| 1 | 1,655 | +113.4 | +23.2 |
| 2 | 1,655 | +119.9 | +9.2 |
| 3 | 1,655 | +88.7 | -0.8 |
| 4 | 1,655 | +101.5 | +3.7 |
| 5 | 1,655 | +55.4 | -22.7 |
| 6 | 1,655 | +74.5 | -6.8 |
| 7 | 1,655 | +62.3 | -21.3 |
| 8 | 1,655 | +30.5 | -31.6 |
| 9 | 1,655 | +56.9 | -18.7 |
| 10 | 1,655 | +55.4 | -10.2 |

## 4. Costs (primary, whole period)

| item | rupees |
|---|---|
| stt | Rs 2,981,134 |
| stamp | Rs 222,574 |
| txn | Rs 95,992 |
| sebi | Rs 2,981 |
| gst | Rs 17,815 |
| dp | Rs 78,089 |
| flat | Rs 0 |
| slip_entry | Rs 1,519,588 |
| slip_exit | Rs 2,768,737 |

Total costs Rs 7,686,911 against gross trading profit Rs 13,474,691 (57% of it).

## 5. Capacity (primary setup at other capital; impact and the 2% liquidity cap bite as size grows)

| capital | CAGR | Sharpe | max DD | avg trade bp | orders capped |
|---|---|---|---|---|---|
| Rs 200,000 | +47.2% | 1.42 | -47.8% | +82.8 | 0 |
| Rs 500,000 | +45.8% | 1.39 | -47.6% | +84.6 | 122 |
| Rs 1,000,000 | +43.3% | 1.35 | -47.6% | +81.5 | 433 |
| Rs 2,500,000 | +37.7% | 1.26 | -47.8% | +79.8 | 1,066 |
| Rs 5,000,000 | +33.5% | 1.22 | -47.4% | +76.9 | 1,767 |
| Rs 10,000,000 | +27.4% | 1.15 | -42.5% | +73.6 | 2,414 |
| Rs 25,000,000 | +20.1% | 1.08 | -23.9% | +70.2 | 3,280 |
| Rs 50,000,000 | +15.8% | 1.07 | -21.2% | +68.4 | 3,806 |

## 6. Construction grid - DESCRIPTIVE (positions per day x hold; the model was trained for 5 sessions)

CAGR / Sharpe / max drawdown. Do not pick the best cell: with 30 cells one will look best by chance.

| n \ hold | 1 | 2 | 3 | 5 | 7 | 10 |
|---|---|---|---|---|---|---|
| 1 | -100% / -1.8 / -100% | -9% / 0.0 / -83% | +13% / 0.5 / -60% | +32% / 1.0 / -54% | +39% / 1.1 / -55% | +44% / 1.3 / -52% |
| 2 | -100% / -2.5 / -100% | -10% / -0.1 / -71% | +20% / 0.7 / -55% | +44% / 1.3 / -46% | +49% / 1.5 / -43% | +50% / 1.5 / -43% |
| 3 | -86% / -2.8 / -100% | -7% / -0.0 / -59% | +20% / 0.7 / -57% | **+43% / 1.4 / -48%** | +45% / 1.4 / -44% | +44% / 1.4 / -45% |
| 5 | -100% / -2.3 / -100% | -4% / 0.0 / -52% | +21% / 0.8 / -53% | +40% / 1.3 / -48% | +44% / 1.5 / -45% | +43% / 1.5 / -46% |
| 10 | -100% / -2.1 / -100% | -11% / -0.3 / -60% | +13% / 0.6 / -48% | +31% / 1.2 / -47% | +36% / 1.3 / -46% | +37% / 1.4 / -46% |

## 7. Rules, engines and costs - DESCRIPTIVE

| variant | CAGR | Sharpe | max DD | trades | avg trade bp |
|---|---|---|---|---|---|
| PRIMARY (D, zerodha_base) | +43.3% | 1.35 | -47.6% | 4,965 | +81.5 |
| ensemble instead of D | +47.5% | 1.47 | -39.7% | 4,965 | +82.4 |
| 50/50 capital D + ensemble | +48.5% | 1.51 | -42.7% | 9,929 | +87.9 |
| flat 35 bp (research convention) | +57.4% | 1.64 | -45.9% | 4,965 | +107.4 |
| stress costs (impact x2, tick both sides) | +27.4% | 0.95 | -49.6% | 4,963 | +59.0 |
| no duplicate holdings | +32.9% | 1.17 | -48.8% | 4,965 | +66.9 |
| stop-loss 5% | +9.2% | 0.51 | -41.3% | 4,965 | +24.7 |
| stop-loss 8% | +22.0% | 0.90 | -33.9% | 4,965 | +42.1 |
| stop-loss 12% | +29.9% | 1.06 | -41.6% | 4,965 | +60.5 |

## 8. Regimes (primary; mean daily return by the universe's state the day before)

| regime | share of days | mean daily bp | annualised |
|---|---|---|---|
| universe down (50d) | 32% | +14.7 | +44.5% |
| universe up (50d) | 68% | +17.1 | +53.3% |
| high vol | 34% | +29.9 | +111.2% |
| low vol | 33% | +6.9 | +18.9% |
| mid vol | 33% | +11.7 | +33.8% |

## 9. What this does not say

- It is not new evidence: same history as the research. The forward paper ledger decides.
- Survivorship, trade-for-trade (BE) and surveillance restrictions are not modelled; taxes are not modelled.
- Fills at the opening auction and the closing price are assumed; the paper test measures real fills.
