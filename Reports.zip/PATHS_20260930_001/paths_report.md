# Inside the trades - frozen engine D, top 3 a day

stage_e_paths v1 | declaration f14e6e968b12a73b | D = STAGED_20260928_001 | 4,965 trades | 35 bp per round trip

**Read this first.** Descriptive only. Every level was fixed before any path was computed and every one is shown. The engine stays frozen: changing the exit rule would be a new engine variant, judged forward.

The current rule (sell at the 5th close, honest exits) nets **+107.4 bp** per trade here.

## 1. How far trades run for (MFE) and against (MAE) you, during the 5 sessions

| | 5th pct | 25th | median | 75th | 95th | mean |
|---|---|---|---|---|---|---|
| best point (MFE) | +0.1% | +2.0% | +5.1% | +10.0% | +21.3% | +7.2% |
| worst point (MAE) | -14.8% | -7.2% | -3.7% | -1.5% | -0.0% | -5.1% |
| where it ends (5th close) | -11.3% | -3.1% | +0.4% | +5.3% | +16.7% | +1.4% |
| MFE in ATRs | +0.03 | +0.49 | +1.10 | +2.04 | +4.24 | +1.53 |
| MAE in ATRs | -2.81 | -1.46 | -0.81 | -0.37 | -0.01 | -1.07 |

Session of the best point: S1 29%, S2 15%, S3 14%, S4 14%, S5 29%  |  session of the worst point: S1 37%, S2 15%, S3 13%, S4 13%, S5 22%

## 2. Where the return is made (average path, % from the entry price)

| session | mean at close | median | share up | mean overnight gap | mean in-session |
|---|---|---|---|---|---|
| 1 | +0.23% | +0.00% | 46% | +0.00% | +0.23% |
| 2 | +0.66% | +0.03% | 51% | +0.37% | +0.07% |
| 3 | +0.94% | +0.10% | 52% | +0.42% | -0.14% |
| 4 | +1.26% | +0.35% | 54% | +0.46% | -0.14% |
| 5 (exit) | +1.52% | +0.45% | 55% | +0.44% | -0.18% |
| 6 | +1.68% | +0.61% | 55% | +0.42% | -0.25% |
| 7 | +1.85% | +0.82% | 56% | +0.41% | -0.25% |
| 8 | +2.02% | +0.85% | 55% | +0.40% | -0.22% |
| 9 | +2.15% | +0.84% | 56% | +0.39% | -0.26% |
| 10 | +2.31% | +1.00% | 56% | +0.39% | -0.24% |

## 3. Time to target: how often +X% is touched, and how fast

| target | touched within 5 | within 10 | median sessions | on session 1 | net if touched (bp, plain exit) | net if not |
|---|---|---|---|---|---|---|
| +2% | 75% | 83% | 1 | 47% | +321 | -534 |
| +3% | 65% | 76% | 2 | 33% | +422 | -488 |
| +5% | 51% | 64% | 3 | 16% | +597 | -399 |
| +8% | 33% | 48% | 4 | 6% | +887 | -276 |
| +10% | 25% | 39% | 4 | 4% | +1082 | -214 |
| +15% | 13% | 24% | 5 | 1% | +1552 | -102 |
| +20% | 6% | 15% | 6 | 0% | +2057 | -21 |

## 4. Stops: how often -X% is touched, and how many eventual winners a stop would have killed

| stop | touched | winners touching it first | losers touching it | net if touched (bp, plain exit) |
|---|---|---|---|---|
| -3% | 57% | 35% | 84% | -209 |
| -5% | 40% | 18% | 66% | -407 |
| -8% | 22% | 6% | 40% | -704 |
| -10% | 14% | 3% | 27% | -889 |

## 5. Target first or stop first - every declared bracket vs the plain 5-session exit

Conservative = stop first when one session touches both (headline); optimistic = target first (bound). With 39 rules, the best one looks good partly by chance - read the years column.

| rule | net bp (conservative) | net bp (optimistic) | vs plain exit | years beating plain exit | target first | stop first | time exit | same-session ambiguous |
|---|---|---|---|---|---|---|---|---|
| TP +2% / SL -3% | -61.9 | -17.7 | -169.2 | 0/7 | 53% | 41% | 6% | 8.8% |
| TP +2% / SL -5% | -52.6 | -27.3 | -160.0 | 0/7 | 64% | 26% | 10% | 3.6% |
| TP +2% / SL -8% | -34.2 | -25.0 | -141.6 | 0/7 | 72% | 14% | 15% | 0.9% |
| TP +2% / SL -10% | -23.3 | -17.8 | -130.7 | 0/7 | 73% | 9% | 18% | 0.5% |
| TP +3% / SL -3% | -42.6 | -11.1 | -150.0 | 0/7 | 46% | 45% | 9% | 5.3% |
| TP +3% / SL -5% | -36.0 | -19.3 | -143.4 | 0/7 | 56% | 30% | 14% | 2.1% |
| TP +3% / SL -8% | -20.7 | -13.3 | -128.0 | 0/7 | 62% | 17% | 21% | 0.7% |
| TP +3% / SL -10% | -8.3 | -4.6 | -115.6 | 0/7 | 64% | 11% | 25% | 0.3% |
| TP +5% / SL -3% | -11.9 | +8.4 | -119.3 | 0/7 | 35% | 51% | 14% | 2.5% |
| TP +5% / SL -5% | -3.4 | +7.3 | -110.7 | 0/7 | 43% | 35% | 22% | 1.1% |
| TP +5% / SL -8% | +16.9 | +23.1 | -90.5 | 0/7 | 49% | 19% | 32% | 0.5% |
| TP +5% / SL -10% | +29.2 | +31.3 | -78.2 | 0/7 | 50% | 12% | 38% | 0.1% |
| TP +8% / SL -3% | +2.6 | +12.1 | -104.8 | 0/7 | 23% | 55% | 23% | 0.9% |
| TP +8% / SL -5% | +14.9 | +21.5 | -92.4 | 0/7 | 28% | 38% | 34% | 0.5% |
| TP +8% / SL -8% | +39.1 | +41.6 | -68.3 | 0/7 | 32% | 21% | 48% | 0.2% |
| TP +8% / SL -10% | +50.7 | +52.5 | -56.7 | 0/7 | 32% | 13% | 54% | 0.1% |
| TP +10% / SL -3% | +10.6 | +18.2 | -96.8 | 0/7 | 17% | 56% | 27% | 0.6% |
| TP +10% / SL -5% | +24.4 | +28.9 | -83.0 | 0/7 | 21% | 39% | 40% | 0.3% |
| TP +10% / SL -8% | +49.8 | +51.7 | -57.5 | 1/7 | 24% | 21% | 55% | 0.1% |
| TP +10% / SL -10% | +61.3 | +62.9 | -46.0 | 1/7 | 24% | 14% | 62% | 0.1% |
| TP +15% / SL -3% | +18.7 | +20.1 | -88.7 | 0/7 | 9% | 57% | 34% | 0.1% |
| TP +15% / SL -5% | +35.1 | +36.3 | -72.2 | 0/7 | 11% | 39% | 50% | 0.1% |
| TP +15% / SL -8% | +62.0 | +62.0 | -45.4 | 1/7 | 12% | 22% | 66% | 0.0% |
| TP +15% / SL -10% | +73.4 | +73.4 | -34.0 | 1/7 | 12% | 14% | 74% | 0.0% |
| TP 1 ATR / SL 1 ATR | +9.7 | +15.8 | -97.6 | 0/7 | 48% | 37% | 15% | 0.6% |
| TP 1 ATR / SL 1.5 ATR | +27.1 | +30.4 | -80.3 | 0/7 | 52% | 22% | 26% | 0.3% |
| TP 1 ATR / SL 2 ATR | +38.5 | +39.4 | -68.8 | 1/7 | 53% | 12% | 34% | 0.1% |
| TP 1.5 ATR / SL 1 ATR | +29.9 | +32.9 | -77.5 | 0/7 | 34% | 39% | 27% | 0.3% |
| TP 1.5 ATR / SL 1.5 ATR | +45.7 | +48.1 | -61.7 | 0/7 | 36% | 23% | 41% | 0.2% |
| TP 1.5 ATR / SL 2 ATR | +58.3 | +59.4 | -49.1 | 0/7 | 37% | 13% | 50% | 0.1% |
| TP 2 ATR / SL 1 ATR | +38.6 | +40.5 | -68.8 | 0/7 | 23% | 40% | 37% | 0.2% |
| TP 2 ATR / SL 1.5 ATR | +56.3 | +57.5 | -51.1 | 0/7 | 25% | 24% | 51% | 0.1% |
| TP 2 ATR / SL 2 ATR | +70.2 | +70.5 | -37.2 | 2/7 | 26% | 13% | 61% | 0.0% |
| TP 3 ATR / SL 1 ATR | +51.5 | +51.5 | -55.8 | 0/7 | 12% | 41% | 48% | 0.0% |
| TP 3 ATR / SL 1.5 ATR | +69.0 | +69.0 | -38.3 | 0/7 | 12% | 24% | 64% | 0.0% |
| TP 3 ATR / SL 2 ATR | +82.2 | +82.2 | -25.1 | 0/7 | 12% | 13% | 74% | 0.0% |
| trailing 5% from the highest close | +34.6 | +34.6 | -72.7 | 0/7 | 0% | 54% | 46% | 0.0% |
| trailing 8% from the highest close | +56.0 | +56.0 | -51.4 | 0/7 | 0% | 29% | 71% | 0.0% |
| trailing 12% from the highest close | +81.2 | +81.2 | -26.2 | 0/7 | 0% | 12% | 88% | 0.0% |

## 6. Giveback

Average best point +7.2%, average finish +1.4%: the plain exit keeps 20% of the average best point. Of trades that were up 3% at some point, 26% finished below entry; of those up 5%, 22% finished below +1%.

## 7. By rank

| rank | trades | mean MFE | mean MAE | net bp |
|---|---|---|---|---|
| 1 | 1,655 | +7.4% | -5.4% | +113.4 |
| 2 | 1,655 | +7.3% | -5.0% | +119.9 |
| 3 | 1,655 | +6.9% | -5.0% | +88.7 |

The ensemble's top 3, same rules: 4,965 trades, MFE +7.2%, MAE -5.0%, plain-exit net +111.7 bp.

## 8. What this does not say

- Daily bars cannot order events inside a session: the ambiguous column says how often that matters.
- Stop and target fills assume the level trades; a gap fills at the open, a frozen lower circuit not at all.
- Same history as the research. A rule change is a new engine variant for the forward test.
