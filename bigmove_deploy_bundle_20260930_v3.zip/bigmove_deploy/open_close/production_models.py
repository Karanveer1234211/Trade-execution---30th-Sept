#!/usr/bin/env python3
"""
production_models.py - train the frozen engines' production models ONCE, on all
resolved history, with the frozen recipe; then fingerprint them.

    python production_models.py train --panel %CACHE_DAILY_ROOT%\\panel_oc

The walk-forward runs never kept their fold models. For paper trading the same
recipe is fitted once on every resolved row (the walk-forward's "next fold"):
  D      stage D's HistGradientBoosting on the 205 features the frozen D run lists,
         in that order; label = day-demeaned label_oc_5, clipped at the 1st/99th
         percentiles; eligible rows only; 400,000-row subsample
  C      the same on the 123 C features the frozen ensemble's C run lists
         (the ensemble = 0.5 x rank(D score) + 0.5 x rank(C score) each day)
Refuses unless the research freeze verifies. Writes <panel>\\frozen\\production\\
D.pkl, C.pkl and PRODUCTION.json (feature lists, rows, training end, SHA-256 of
each model); ledger entry production_frozen. No retraining during the paper test.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import pickle
import sys
import time
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import research_common as RC       # first: from a subfolder, this folder's copy must win
import panel_build as PB           # noqa: E402,F401
import stage_b_screen as SB        # noqa: E402
import stage_d_gate as SD          # noqa: E402
import stage_c_screen as SCS       # noqa: E402
import freeze_engines as FZ        # noqa: E402

CODE_VERSION = "production_models v1.1"   # v1.1: records library versions; refuses to load under different ones
PROD_SEED = [7, 99, 5]


class PreconditionError(SystemExit):
    pass


def _log(msg: str) -> None:
    print(f"{dt.datetime.now():%H:%M:%S}  {msg}", flush=True)


def lib_versions() -> dict:
    import sklearn
    return {"python": sys.version.split()[0], "numpy": np.__version__, "pandas": pd.__version__, "sklearn": sklearn.__version__}


def prod_dir(pp: Path) -> Path:
    return pp.parent / "frozen" / "production"


def frozen_features(pp: Path, man: dict) -> Tuple[List[str], List[str]]:
    root = pp.parent / "stage_d"
    d = json.loads((root / man["engines"]["D"]["run"] / "stage_d.json").read_text(encoding="utf-8"))
    c = json.loads((root / man["engines"]["ENS"]["c_run"] / "stage_d.json").read_text(encoding="utf-8"))
    if not d.get("features") or not c.get("features"):
        raise PreconditionError("the frozen runs do not list their features")
    return list(d["features"]), list(c["features"])


def training_rows(pp: Path, target: str):
    b = pd.read_parquet(pp, columns=["timestamp", "symbol", SB.ELIG_COL, target])
    ts = SB._naive(b["timestamp"]).to_numpy(dtype="datetime64[ns]")
    buy = pd.to_numeric(b[SB.ELIG_COL], errors="coerce").to_numpy(float)
    y = pd.to_numeric(b[target], errors="coerce").to_numpy(float)
    rows = np.flatnonzero(SD.eligible_mask(buy) & np.isfinite(y))
    day = np.searchsorted(np.unique(ts), ts)
    return rows, day, y, ts


def fit_one(X: np.ndarray, y: np.ndarray, day: np.ndarray, cfg: dict, seed: List[int]):
    from sklearn.ensemble import HistGradientBoostingRegressor
    lab, lo, hi = SD.make_label(y, day, cfg["winsor_pct"])
    rng = np.random.default_rng(seed)
    keep = np.arange(len(y)) if len(y) <= cfg["fit_cap"] else np.sort(rng.choice(len(y), cfg["fit_cap"], replace=False))
    m = HistGradientBoostingRegressor(random_state=cfg["seed"], **cfg["hgb"])
    m.fit(X[keep], lab[keep])
    return m, {"train_rows": int(len(y)), "fit_rows": int(len(keep)), "label_clip_bp": [lo * 1e4, hi * 1e4]}


def train(pp: Path, verbose=True) -> dict:
    man = FZ.verify_frozen(pp)
    _, dsha = SD.load_declaration()
    cfg = SD.CFG
    d_feats, c_feats = frozen_features(pp, man)
    rows, day, y, ts = training_rows(pp, man["target"])
    t0 = time.perf_counter()
    out = {}
    read_c = SCS.reader_for(pp)
    for tag, feats, reader in (("D", d_feats, lambda f: SB._read_col(pp, f)), ("C", c_feats, read_c)):
        X = np.empty((len(rows), len(feats)), dtype=np.float32)
        for j, f in enumerate(feats):
            X[:, j] = reader(f)[rows]
        model, info = fit_one(X, y[rows], day[rows], cfg, PROD_SEED)
        del X
        out[tag] = {"model": model, "features": feats, **info,
                    "train_end": str(pd.Timestamp(ts[rows].max()).date())}
        if verbose:
            _log(f"{tag}: fitted on {info['fit_rows']:,} of {info['train_rows']:,} resolved eligible rows "
                 f"to {out[tag]['train_end']} ({time.perf_counter() - t0:.0f}s)")
    return {"models": out, "stage_d_declaration_sha": dsha, "freeze": man}


def save(pp: Path, res: dict) -> dict:
    d = prod_dir(pp)
    d.mkdir(parents=True, exist_ok=True)
    meta = {"tool": CODE_VERSION, "trained_at": dt.datetime.now().isoformat(), "seed": PROD_SEED,
            "stage_d_declaration_sha": res["stage_d_declaration_sha"], "target": res["freeze"]["target"],
            "engines": {"D": res["freeze"]["engines"]["D"]["run"], "ENS": res["freeze"]["engines"]["ENS"]["run"]},
            "libraries": lib_versions(), "models": {}}
    for tag, m in res["models"].items():
        fp = d / f"{tag}.pkl"
        with open(fp, "wb") as f:
            pickle.dump(m["model"], f, protocol=pickle.HIGHEST_PROTOCOL)
        meta["models"][tag] = {"file": fp.name, "sha256": FZ.sha(fp), "features": m["features"],
                               "train_rows": m["train_rows"], "fit_rows": m["fit_rows"],
                               "train_end": m["train_end"], "label_clip_bp": m["label_clip_bp"]}
    (d / "PRODUCTION.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return meta


def load_verified(pp: Path) -> Tuple[dict, Dict[str, object]]:
    """PRODUCTION.json and the unpickled models, after checking every model's SHA-256."""
    d = prod_dir(pp)
    mp = d / "PRODUCTION.json"
    if not mp.exists():
        raise PreconditionError("no production models - run production_models.py train first")
    meta = json.loads(mp.read_text(encoding="utf-8"))
    now, then = lib_versions(), meta.get("libraries", {})
    for lib in ("sklearn", "numpy"):
        if then.get(lib) and then[lib] != now[lib]:
            raise PreconditionError(f"{lib} is {now[lib]} but the production models were trained under {then[lib]} - "
                                    f"reinstall {lib}=={then[lib]}; never upgrade it during the paper test")
    models = {}
    for tag, m in meta["models"].items():
        fp = d / m["file"]
        if not fp.exists() or FZ.sha(fp) != m["sha256"]:
            raise PreconditionError(f"production model {tag} is missing or changed since it was frozen")
        with open(fp, "rb") as f:
            models[tag] = pickle.load(f)
    return meta, models


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Production models for the frozen engines")
    ap.add_argument("cmd", choices=["train", "verify"])
    ap.add_argument("--panel", required=True, help="the RESEARCH panel folder (panel_oc)")
    ap.add_argument("--rerun-reason", default=None)
    a = ap.parse_args(argv)
    pp = Path(a.panel) / "panel.parquet"
    if a.cmd == "verify":
        meta, _ = load_verified(pp)
        print(f"production models verified: " + ", ".join(f"{k} trained to {v['train_end']}" for k, v in meta["models"].items()))
        return 0
    if (prod_dir(pp) / "PRODUCTION.json").exists() and not a.rerun_reason:
        raise PreconditionError("production models already exist; retraining needs --rerun-reason (it creates new engines)")
    print("=" * 76)
    print(f"{CODE_VERSION}: fitting the frozen recipe once on all resolved history")
    print("=" * 76)
    res = train(pp)
    meta = save(pp, res)
    n = RC.ledger_append(pp, {"kind": "production_frozen", "tool": CODE_VERSION,
                              "models": {k: {"sha256": v["sha256"][:16], "train_end": v["train_end"]}
                                         for k, v in meta["models"].items()}, "rerun_reason": a.rerun_reason})
    print(f"\n  models: {prod_dir(pp)}\n  research ledger: entry {n} (production_frozen)")
    print("=" * 76)
    print("PRODUCTION MODELS FROZEN. The paper pipeline verifies their SHA-256 every day.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
