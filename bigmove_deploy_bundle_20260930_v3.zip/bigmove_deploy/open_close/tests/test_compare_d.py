#!/usr/bin/env python3
"""
tests/test_compare_d.py - compare_d_variants v1. Prints VERIFIED on success.

Run from the open_close folder with the main folder on PYTHONPATH:
    python tests\\test_compare_d.py

Uses the forensics test world (raw cache + a stage-D run whose outcomes come from the cache) and adds:
  SAME     a variant identical to the baseline          -> paired difference exactly 0 -> KEEP
  BETTER   a variant whose oc_5 picks are real winners instead of the baseline's locked-exit
           stocks                                        -> REPLACE on oc_5 only
  reversed: BETTER as baseline, the locked-exit picker as variant -> KEEP, although its
           stage-D scoring looked fine: exits are what decide
Checks: corrected nets equal the forensics tool's locked-exit nets (same rule, two tools);
paired means re-derived by pandas; ETFs by ISIN; ledger; unknown runs refused.
"""

from __future__ import annotations

import contextlib
import io
import json
import shutil
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))

import research_common as RC          # noqa: E402
import stage_b_screen as SB           # noqa: E402
import stage_d_gate as SD             # noqa: E402
import stage_d_forensics as SF        # noqa: E402
import compare_d_variants as CV       # noqa: E402
import test_stage_d_forensics as TF   # noqa: E402  (its planted world)

FAILS = []
TARGETS = ["label_oc_1", "label_oc_2", "label_oc_3", "label_oc_5"]


def check(cond, msg):
    print(("  ok  " if cond else "  FAIL") + f"  {msg}")
    if not cond:
        FAILS.append(msg)


def quiet(fn, *a, **k):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        out = fn(*a, **k)
    return out, buf.getvalue()


def add_run(pdir: Path, run_id: str, preds: pd.DataFrame):
    run = pdir / "stage_d" / run_id
    run.mkdir(parents=True)
    preds.to_parquet(run / "preds.parquet", index=False)
    dl = []
    for tg, g in preds.groupby("target"):
        mk = g.groupby("timestamp")["outcome"].mean()
        top = g.sort_values(["timestamp", "score", "symbol"], ascending=[True, False, True]).groupby("timestamp").head(3)
        t3 = top.groupby("timestamp")["outcome"].mean()
        dl.append(pd.DataFrame({"timestamp": mk.index, "target": tg, "market": mk.values,
                                "top3_net": (t3 - 0.0035).reindex(mk.index).values}))
    pd.concat(dl, ignore_index=True).to_csv(run / "daily.csv", index=False)
    RC.ledger_append(pdir / "panel.parquet", {"kind": "stage_d2_run", "experiment_family": "oc_v1", "run_id": run_id})


def main():
    print("0. module origin")
    here = HERE.parent.resolve()
    for m in (CV, SF, SD, SB, RC):
        check(Path(m.__file__).resolve().parent == here, f"{m.__name__} from {Path(m.__file__).resolve().parent}")
    tmp = Path(tempfile.mkdtemp())
    try:
        root, pdir, ip = TF.make_world(tmp)
        pp = pdir / "panel.parquet"
        base = pd.read_parquet(pdir / "stage_d" / "STAGED_T_001" / "preds.parquet")
        add_run(pdir, "STAGED2_SAME", base.copy())
        better = base.copy()
        m5 = better["target"] == "label_oc_5"
        normal = better["symbol"].str.startswith("N")
        better.loc[m5, "score"] = np.where(normal[m5], better.loc[m5, "outcome"], -1.0)
        add_run(pdir, "STAGED2_BETTER", better)

        print("1. SAME and BETTER against the baseline")
        rc, log = quiet(CV.main, ["--panel", str(pdir), "--root", str(root), "--isin", str(ip),
                                  "--runs", "STAGED_T_001", "STAGED2_SAME", "STAGED2_BETTER"])
        out = sorted((pdir / "stage_d" / "compare").iterdir())[-1]
        J = json.loads((out / "compare.json").read_text())
        C = J["comparison"]
        same = C["decisions"]["STAGED2_SAME"]
        check(all(abs(same[tg]["paired_diff"]["mean"]) < 1e-15 and not same[tg]["replaces_baseline"]
                  and abs(same[tg]["pick_overlap_with_baseline"] - 1) < 1e-12 for tg in TARGETS),
              "identical variant: paired difference exactly 0, same picks 100%, KEEP on every target")
        bt = C["decisions"]["STAGED2_BETTER"]
        check(bt["label_oc_5"]["replaces_baseline"] and bt["label_oc_5"]["paired_diff"]["lo"] > 0,
              f"BETTER replaces the baseline on oc_5 (paired {bt['label_oc_5']['paired_diff']['mean'] * 1e4:+.1f} bp, "
              f"lower bound {bt['label_oc_5']['paired_diff']['lo'] * 1e4:+.1f})")
        check(not any(bt[tg]["replaces_baseline"] for tg in ("label_oc_1", "label_oc_2", "label_oc_3")),
              "BETTER keeps the baseline where it is identical (oc_1, oc_2, oc_3)")
        check(not C["runs"]["STAGED_T_001"]["label_oc_3"]["pass"], "ETFs out by ISIN: the ETF-only oc_3 fails")

        fr, _ = quiet(SF.run_forensics, pp, root, pdir / "stage_d" / "STAGED_T_001", TARGETS,
                      SF.load_isin_files([str(ip)]), verbose=False)
        dc = pd.read_csv(out / "daily_corrected.csv", parse_dates=["timestamp"])
        worst = 0.0
        for tg in TARGETS:
            a = dc[(dc["run"] == "STAGED_T_001") & (dc["target"] == tg)]["net_corr"].mean()
            worst = max(worst, abs(a - fr["results"][tg]["lock_net"]["mean"]))
        check(worst < 1e-12, f"corrected nets = the forensics tool's locked-exit nets (max diff {worst:.1e})")
        worst = 0.0
        for tg in TARGETS:
            a = dc[(dc["run"] == "STAGED_T_001") & (dc["target"] == tg)].set_index("timestamp")["net_corr"]
            b = dc[(dc["run"] == "STAGED2_BETTER") & (dc["target"] == tg)].set_index("timestamp")["net_corr"]
            worst = max(worst, abs((b - a).dropna().mean() - bt[tg]["paired_diff"]["mean"]))
        check(worst < 1e-12, f"paired means re-derived by pandas from daily_corrected.csv (max diff {worst:.1e})")

        print("2. reversed: the locked-exit picker as the variant")
        rc, log = quiet(CV.main, ["--panel", str(pdir), "--root", str(root), "--isin", str(ip),
                                  "--runs", "STAGED2_BETTER", "STAGED_T_001"])
        out2 = sorted((pdir / "stage_d" / "compare").iterdir())[-1]
        C2 = json.loads((out2 / "compare.json").read_text())["comparison"]
        lk = C2["runs"]["STAGED_T_001"]["label_oc_5"]
        d2 = C2["decisions"]["STAGED_T_001"]["label_oc_5"]
        check(lk["stage_d_scoring_mean"] > 0 > lk["net"]["mean"] and not d2["replaces_baseline"],
              f"its stage-D scoring said {lk['stage_d_scoring_mean'] * 1e4:+.1f} bp; with honest exits "
              f"{lk['net']['mean'] * 1e4:+.1f} -> KEEP BASELINE")
        rep = (out2 / "compare_report.md").read_text(encoding="utf-8")
        check("KEEP BASELINE" in rep and "locked at the lower band" in rep, "report states decisions and the exit rule")
        led = [e for e in RC.ledger_entries(pp) if e.get("kind") == "stage_d_compare"]
        check(len(led) == 2 and led[-1]["decisions"]["STAGED_T_001"]["label_oc_5"] is False,
              "both comparisons logged with their decisions")
        try:
            quiet(CV.main, ["--panel", str(pdir), "--root", str(root), "--runs", "STAGED_T_001", "NOPE"])
            check(False, "an unknown run is refused")
        except SystemExit as e:
            check("NOPE" in str(e), "an unknown run is refused")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print()
    if FAILS:
        print(f"FAILED  {len(FAILS)} check(s):")
        for f in FAILS:
            print("   - " + f)
        return 1
    print(f"VERIFIED  {CV.CODE_VERSION}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
