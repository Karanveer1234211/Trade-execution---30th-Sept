#!/usr/bin/env python3
"""
tests/test_stage_d_forensics.py - stage_d_forensics v1. Prints VERIFIED on success.

Run from the open_close folder with the main folder on PYTHONPATH:
    python tests\\test_stage_d_forensics.py

 0. Module origin (no shadowing by the main folder).
 1. Tick sizes on both sides of 2024-06-10 and 2025-04-15, at every price boundary.
 2. Re-scoring by hand: a clean exit is untouched; an exit locked at the lower band moves to the
    first open that is not itself locked; a lock that outlasts the data or the 20-session search
    is flagged; frozen entries and upper-band exits are flagged.
 3. ISIN files in three layouts (new bhavcopy, old bhavcopy, EQUITY_L) and zipped: INF = ETF,
    INE = stock, missing = name rule.
 4. A planted world where each target fails a DIFFERENT correction:
      oc_1  real skill in ordinary stocks                  -> survives all three -> PASS
      oc_2  profits only in Rs 1.5 stocks                  -> dies at the tick cost
      oc_3  profits only in ETFs the name rule misses      -> dies when ETFs go out by ISIN
      oc_5  profits only from exits locked at the lower band, whose first sellable open is
            ~8.5% lower                                    -> dies at the locked-exit rule
    plus: 100% of outcomes re-derived from the raw cache; daily numbers re-derived by pandas
    from trades.csv; ledger order; re-run guard.
 5. Integrity stop and preconditions: corrupted stage-D outcomes -> IntegrityError; missing ISIN
    file, no stage-D run, a changed declaration -> refused.
"""

from __future__ import annotations

import contextlib
import io
import json
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

import research_common as RC        # noqa: E402
import panel_build as PB            # noqa: E402
import stage_b_screen as SB         # noqa: E402
import stage_d_gate as SD           # noqa: E402
import stage_d_forensics as SF      # noqa: E402

FAILS = []
TARGETS = ["label_oc_1", "label_oc_2", "label_oc_3", "label_oc_5"]


def check(cond, msg):
    print(("  ok  " if cond else "  FAIL") + f"  {msg}")
    if not cond:
        FAILS.append(msg)


def quiet(fn, *a, **k):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        out = fn(*a, **k)
    return out, buf.getvalue()


def test_origin():
    print("0. module origin")
    here = HERE.parent.resolve()
    for m in (SF, SD, SB, RC, PB):
        check(Path(m.__file__).resolve().parent == here, f"{m.__name__} from {Path(m.__file__).resolve().parent}")


def test_ticks():
    print("1. tick sizes")
    cases = [("2024-06-07", 100, 0.05), ("2024-06-07", 3000, 0.05), ("2024-06-10", 100, 0.01),
             ("2024-06-10", 249.99, 0.01), ("2024-06-10", 250, 0.05), ("2025-04-14", 1500, 0.05),
             ("2025-04-15", 100, 0.01), ("2025-04-15", 250, 0.05), ("2025-04-15", 1000, 0.05),
             ("2025-04-15", 1000.5, 0.10), ("2025-04-15", 5000, 0.10), ("2025-04-15", 6000, 0.50),
             ("2025-04-15", 15000, 1.00), ("2025-04-15", 25000, 5.00)]
    d = np.array([np.datetime64(x, "ns") for x, _, _ in cases])
    got = SF.tick_size(d, [p for _, p, _ in cases])
    want = np.array([t for _, _, t in cases])
    bad = [(cases[i][0], cases[i][1], got[i]) for i in range(len(cases)) if abs(got[i] - want[i]) > 1e-12]
    check(not bad, f"{len(cases)} boundary cases match NSE's schedule" + (f" - wrong: {bad}" if bad else ""))


def bars(rows):
    o, h, l, c = (np.array([r[k] for r in rows], float) for k in range(4))
    return o, h, l, c


def test_rescore():
    print("2. re-scoring by hand")
    B = 500.0
    c4 = 1.1368 * B
    c5 = 0.95 * c4
    c6 = 0.95 * c5
    o7 = 0.97 * c6
    rows = [(B, B * 1.002, B * 0.998, B),                    # 0 signal day
            (B, 1.021 * B * 1.002, B * 0.998, 1.021 * B),    # 1 entry at the open
            (1.021 * B, 1.05 * B * 1.002, 1.021 * B * 0.998, 1.05 * B),
            (1.05 * B, 1.08 * B * 1.002, 1.05 * B * 0.998, 1.08 * B),
            (1.08 * B, c4 * 1.002, 1.08 * B * 0.998, c4),
            (c4, c4, c5, c5),                                # 5 exit: closes locked at -5%
            (c6, c6, c6, c6),                                # 6 opens locked at -5% (frozen)
            (o7, o7 * 1.002, o7 * 0.998, o7),                # 7 first sellable open
            (o7, o7, o7, o7)]
    o, h, l, c = bars(rows)
    r = SF.rescore_symbol(o, h, l, c, np.array([0]), 5, 20)
    check(bool(r["locked_exit"][0]) and r["exit_shift"][0] == 2 and abs(r["exit_px"][0] - o7) < 1e-9,
          f"locked exit moves to the first unlocked open 2 sessions later ({r['outcome'][0]:+.2%} -> "
          f"{r['outcome_lock'][0]:+.2%})")
    r2 = SF.rescore_symbol(o, h, l, c, np.array([0]), 3, 20)
    check(not r2["locked_exit"][0] and r2["outcome_lock"][0] == r2["outcome"][0], "a clean exit is untouched")
    r3 = SF.rescore_symbol(o[:7], h[:7], l[:7], c[:7], np.array([0]), 5, 20)
    check(bool(r3["still_locked"][0]) and abs(r3["exit_px"][0] - c6) < 1e-9,
          "a lock that outlasts the data exits at the last close, flagged")
    r4 = SF.rescore_symbol(o[:6], h[:6], l[:6], c[:6], np.array([0]), 5, 20)
    check(bool(r4["no_later_bar"][0]) and r4["outcome_lock"][0] == r4["outcome"][0],
          "a locked exit on the last bar keeps its close, flagged")
    r5 = SF.rescore_symbol(o, h, l, c, np.array([5]), 1, 20)
    check(bool(r5["frozen_entry"][0]) and bool(r5["entry_lower_band"][0]),
          "a frozen entry day at the lower band is flagged (a buy there fills: allowed)")
    pen = [(2.0, 2.01, 1.99, 2.0), (2.0, 2.01, 1.99, 2.0), (2.0, 2.0, 1.976, 1.976), (1.97, 1.99, 1.96, 1.98)]
    o, h, l, c = bars(pen)
    late = np.array([np.datetime64(x, "ns") for x in ("2024-07-01", "2024-07-02", "2024-07-03", "2024-07-04")])
    early = late - np.timedelta64(400, "D")
    rl = SF.rescore_symbol(o, h, l, c, np.array([0]), 2, 20, late)
    re_ = SF.rescore_symbol(o, h, l, c, np.array([0]), 2, 20, early)
    check(not rl["locked_exit"][0] and bool(re_["locked_exit"][0]),
          "a Rs 2 stock closing -1.2% at its low: a lock under the Rs 0.05 tick (one tick from the 2% band), "
          "not under the Rs 0.01 tick of 2024-06-10 on")
    up = [(100, 100.2, 99.8, 100), (100, 110, 99.9, 110)]
    o, h, l, c = bars(up)
    r6 = SF.rescore_symbol(np.r_[100, o], np.r_[100.2, h], np.r_[99.8, l], np.r_[100, c], np.array([0]), 2, 20)
    check(bool(r6["exit_upper_band"][0]) and not r6["locked_exit"][0],
          "an exit that closes locked at the UPPER band is flagged but kept (selling into it fills)")


def test_isin(tmp: Path):
    print("3. ISIN files")
    new = pd.DataFrame({"TradDt": "2026-09-28", "TckrSymb": ["AAA", "LIQUIDX", "BBB", "BBB"],
                        "SctySrs": ["EQ", "EQ", "BE", "EQ"],
                        "ISIN": ["INE000A01010", "INF000X01011", "INE000B01012", "INE000B01012"]})
    old = pd.DataFrame({"SYMBOL": ["CCC", "GOLDX"], "SERIES": ["EQ", "EQ"], "OPEN": [1, 2],
                        "ISIN": ["INE000C01013", "INF000G01014"]})
    eql = pd.DataFrame({"SYMBOL": ["DDD"], "NAME OF COMPANY": ["D Ltd"], " SERIES": ["EQ"],
                        " ISIN NUMBER": ["INE000D01015"]})
    p1, p2, p3 = tmp / "BhavCopy_NSE_CM_new.csv", tmp / "cm28SEP2026bhav.csv", tmp / "EQUITY_L.csv"
    new.to_csv(p1, index=False)
    old.to_csv(p2, index=False)
    eql.to_csv(p3, index=False)
    z = tmp / "BhavCopy_NSE_CM_new.csv.zip"
    with zipfile.ZipFile(z, "w") as zf:
        zf.write(p1, arcname=p1.name)
    df = SF.load_isin_files([str(z), str(p2), str(p3)])
    check(set(df["symbol"]) == {"AAA", "LIQUIDX", "BBB", "CCC", "GOLDX", "DDD"}, "three layouts (one zipped) parsed")
    check(df.set_index("symbol").at["BBB", "series"] == "EQ", "a symbol listed in two series keeps its EQ line")
    cl = SF.classify_symbols(["AAA", "LIQUIDX", "GOLDX", "DDD", "NIFTYBEES", "ZZZ"], df, set()).set_index("symbol")
    check(bool(cl.at["LIQUIDX", "etf"]) and bool(cl.at["GOLDX", "etf"]) and not cl.at["AAA", "etf"]
          and not cl.at["DDD", "etf"], "INF... = ETF, INE... = stock, even when the name rule would not know")
    check(cl.at["NIFTYBEES", "how"] == "name_rule" and bool(cl.at["NIFTYBEES", "etf"]) and not cl.at["ZZZ", "etf"],
          "symbols without an ISIN fall back to the name rule")


# ----------------------------------------------------------------------
def make_world(tmp: Path, seed: int = 11):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2022-01-03", "2025-12-31")
    dv = dates.values.astype("datetime64[ns]")
    T = len(dates)
    root = tmp / "cache"
    root.mkdir()
    series = {}
    for k in range(30):
        c = np.exp(rng.uniform(np.log(100), np.log(2000))) * np.exp(np.cumsum(0.01 * rng.normal(size=T)))
        o = np.r_[c[0], c[:-1]] * np.exp(0.003 * rng.normal(size=T))
        series[f"N{k:02d}"] = (o, np.maximum(o, c) * 1.005, np.minimum(o, c) * 0.995, c)

    def intraday_up(p0, gap, lift):
        o, c = np.empty(T), np.empty(T)
        prev = p0
        for t in range(T):
            o[t] = prev * gap
            c[t] = o[t] * lift * np.exp(0.0005 * rng.normal())
            prev = c[t]
        return o, c * 1.001, o * 0.999, c
    for k in range(3):
        series[f"P{k}"] = intraday_up(1.5, 0.988, 1.012)
    series["LIQUIDX"] = intraday_up(100.0, 0.985, 1.015)
    series["GOLDX"] = intraday_up(60.0, 0.985, 1.015)
    B = 500.0
    cyc_c = np.array([1.0, 1.021, 1.05, 1.08, 1.1368, 1.1368 * 0.95, 1.1368 * 0.95 ** 2,
                      1.1368 * 0.95 ** 2 * 0.97, 0.998, 1.0])
    for m, off in enumerate((0, 3, 6)):
        o, h, l, c = np.empty(T), np.empty(T), np.empty(T), np.empty(T)
        for t in range(T):
            kpos = (t - off) % 10
            cc = cyc_c[kpos] * B
            prev = c[t - 1] if t else B
            if kpos == 6:
                oo = cc
                o[t], h[t], l[t], c[t] = oo, oo, oo, oo
                continue
            oo = prev * 0.97 if kpos == 7 else prev       # 7: first sellable open, 3% below the frozen price
            o[t], c[t] = oo, cc
            if kpos == 5:
                h[t], l[t] = max(oo, cc), cc
            else:
                h[t], l[t] = max(oo, cc) * 1.002, min(oo, cc) * 0.998
        series[f"LOCK{m}"] = (o, h, l, c)
    for s, (o, h, l, c) in series.items():
        pd.DataFrame({"timestamp": dv, "open": o, "high": h, "low": l, "close": c, "volume": 1e5}).to_parquet(
            root / f"{s}_daily.parquet", index=False)

    test = np.arange(40, T - 10)
    rows, prow = [], []
    for s, (o, h, l, c) in series.items():
        for tg in TARGETS:
            hz = SD.horizon_of(tg)
            out = c[test + hz] / o[test + 1] - 1
            if tg == "label_oc_1":
                sc = (out + 0.004 * rng.normal(size=len(test))) if s.startswith("N") else -1.0 + 0 * out
            elif tg == "label_oc_2":
                sc = (1.0 + 0.01 * rng.normal(size=len(test))) if s.startswith("P") else rng.normal(size=len(test)) * 0.1
            elif tg == "label_oc_3":
                sc = (1.0 + 0.01 * rng.normal(size=len(test))) if s in ("LIQUIDX", "GOLDX") else rng.normal(size=len(test)) * 0.1
            else:
                if s.startswith("LOCK"):
                    off = (0, 3, 6)[int(s[-1])]
                    sc = np.where((test - off) % 10 == 0, 1.0, -1.0)
                else:
                    sc = rng.normal(size=len(test)) * 0.1
            rows.append(pd.DataFrame({"timestamp": dv[test], "symbol": s, "target": tg,
                                      "score": sc.astype("float32"), "outcome": out.astype("float32")}))
        prow.append(pd.DataFrame({"timestamp": dv, "symbol": s, "close": c, "X_turnover_med": 5e8,
                                  "label_buyable_o1": 1.0}))
    preds = pd.concat(rows, ignore_index=True)
    preds["outcome"] = preds["outcome"].astype("float64")
    pdir = tmp / "panel_oc"
    pdir.mkdir()
    pd.concat(prow, ignore_index=True).to_parquet(pdir / "panel.parquet", index=False)
    (pdir / "panel_meta.json").write_text(json.dumps({"panel_build_version": PB.PANEL_BUILD_VERSION,
        "built_at": (pd.Timestamp.now() - pd.Timedelta(hours=3)).isoformat()}), encoding="utf-8")
    _, sha = SB.load_manifest()
    pp = pdir / "panel.parquet"
    RC.ledger_append(pp, {"kind": "panel_audit", "passed": True, "manifest_sha": sha})
    RC.ledger_append(pp, {"kind": "stage_b_screen", "experiment_family": "oc_v1", "run_id": "STAGEB_T"})
    run = pdir / "stage_d" / "STAGED_T_001"
    run.mkdir(parents=True)
    preds.to_parquet(run / "preds.parquet", index=False)
    dl = []
    for tg, g in preds.groupby("target"):
        mk = g.groupby("timestamp")["outcome"].mean()
        top = g.sort_values(["timestamp", "score", "symbol"], ascending=[True, False, True]).groupby("timestamp").head(3)
        t3 = top.groupby("timestamp")["outcome"].mean()
        dl.append(pd.DataFrame({"timestamp": mk.index, "target": tg, "market": mk.values,
                                "top3_net": (t3 - 0.0035).reindex(mk.index).values}))
    pd.concat(dl, ignore_index=True).to_csv(run / "daily.csv", index=False)
    (run / "stage_d.json").write_text("{}", encoding="utf-8")
    RC.ledger_append(pp, {"kind": "stage_d_gate", "experiment_family": "oc_v1", "run_id": "STAGED_T_001"})
    isin = pd.DataFrame({"TckrSymb": list(series), "SctySrs": ["BE" if s == "LOCK1" else "EQ" for s in series],
                         "ISIN": [("INF" if s in ("LIQUIDX", "GOLDX") else "INE") + f"{i:09d}" for i, s in enumerate(series)]})
    isin = isin[isin["TckrSymb"] != "N29"]           # one stock with no ISIN: the name rule decides
    ip = tmp / "BhavCopy_NSE_CM_0_0_0_20251231_F_0000.csv"
    isin.to_csv(ip, index=False)
    return root, pdir, ip


def test_world(tmp: Path):
    print("4. a planted world: each target fails a different correction")
    root, pdir, ip = make_world(tmp)
    pp = pdir / "panel.parquet"
    rc, log = quiet(SF.main, ["--panel", str(pdir), "--root", str(root), "--isin", str(ip)])
    out = sorted((pdir / "stage_d" / "STAGED_T_001" / "forensics").iterdir())[-1]
    for fn in ("forensics_report.md", "forensics.json", "trades.csv", "etf_classification.csv"):
        check((out / fn).exists(), f"output {fn}")
    J = json.loads((out / "forensics.json").read_text(encoding="utf-8"))
    R = J["results"]
    m = lambda tg, k: R[tg][k]["mean"] * 1e4
    check(J["match_rate"] == 1.0, "100% of picks re-derive stage D's outcome from the raw cache")
    check(set(J["etf_missed_by_name_rule"]) == {"LIQUIDX", "GOLDX"}, "the ISIN catches the two ETFs the name rule misses")
    check(R["label_oc_1"]["verdict"]["pass"], f"oc_1 (real skill, ordinary stocks): PASS (final {m('label_oc_1', 'final_net'):+.1f} bp)")
    v2 = R["label_oc_2"]
    check(not v2["verdict"]["pass"] and m("label_oc_2", "lock_net") > 0 > m("label_oc_2", "final_net"),
          f"oc_2 (Rs 1.5 stocks): +{m('label_oc_2', 'lock_net'):.1f} bp before ticks -> {m('label_oc_2', 'final_net'):+.1f} "
          f"after one tick -> FAIL")
    check(v2["tick_cost_bp"]["share_above_35bp"] == 1.0 and v2["price_buckets"]["[0.0, 10.0)"]["share"] == 1.0,
          f"oc_2: every pick priced under Rs 10, tick cost above 35 bp on all (mean {v2['tick_cost_bp']['mean']:.0f} bp)")
    v3 = R["label_oc_3"]
    check(not v3["verdict"]["pass"] and m("label_oc_3", "as_run_net") > 0 > m("label_oc_3", "etf_net")
          and v3["etf_in_original_top3"] > 0,
          f"oc_3 (ETFs): {m('label_oc_3', 'as_run_net'):+.1f} bp as run -> {m('label_oc_3', 'etf_net'):+.1f} with ETFs out -> FAIL")
    v5 = R["label_oc_5"]
    check(not v5["verdict"]["pass"] and m("label_oc_5", "etf_net") > 0 > m("label_oc_5", "lock_net"),
          f"oc_5 (locked exits): {m('label_oc_5', 'etf_net'):+.1f} bp -> {m('label_oc_5', 'lock_net'):+.1f} once locked "
          f"exits move to the first sellable open -> FAIL")
    check(v5["locked_exits"]["count"] > 0 and abs(v5["locked_exits"]["mean_cost_bp"] - (0.995183 / 1.0 - 1.08 / 1.0) * 1e4) < 5,
          f"oc_5: {v5['locked_exits']['count']} locked exits, each costing {v5['locked_exits']['mean_cost_bp']:+.0f} bp "
          f"(planted: 8.0% -> -0.5%)")
    tr = pd.read_csv(out / "trades.csv", parse_dates=["timestamp", "entry_date"])
    worst = 0.0
    for tg in TARGETS:
        g = tr[tr["target"] == tg]
        tick = np.where(g["entry_date"] < pd.Timestamp("2024-06-10"), 0.05,
                        np.where(g["entry"] < 250, 0.01, 0.05))
        tick = np.where(g["entry_date"] >= pd.Timestamp("2025-04-15"),
                        np.select([g["entry"] < 250, g["entry"] <= 1000, g["entry"] <= 5000], [0.01, 0.05, 0.10], 0.5), tick)
        nf = g["outcome_lock"] - 0.0035 - tick / g["entry"]
        day = nf.groupby(g["timestamp"]).mean()
        worst = max(worst, abs(day.mean() * 1e4 - m(tg, "final_net")))
    check(worst < 1e-6, f"every target's final daily net re-derived by pandas from trades.csv (max diff {worst:.1e} bp)")
    rep = (out / "forensics_report.md").read_text(encoding="utf-8")
    check("**PASS**" in rep and "Survivorship" in rep and "restricted series TODAY" in rep,
          "report carries verdicts and the unmeasurable risks")
    check("LOCK1" in tr.loc[tr["current_series"] == "BE", "symbol"].unique(), "today's BE series reported (descriptive)")
    led = RC.ledger_entries(pp)
    kinds = [e.get("kind") for e in led]
    check(kinds.index("stage_d_forensics_declared") < kinds.index("stage_d_forensics")
          and led[kinds.index("stage_d_forensics")]["passed"] == ["label_oc_1"],
          "ledger: declaration hash before the results; passed = [label_oc_1]")
    try:
        quiet(SF.main, ["--panel", str(pdir), "--root", str(root), "--isin", str(ip)])
        check(False, "a second run without --rerun-reason is refused")
    except SystemExit as e:
        check("already ran" in str(e), "a second run without --rerun-reason is refused")
    return root, pdir, ip


def test_stops(tmp: Path, root: Path, pdir: Path, ip: Path):
    print("5. integrity stop and preconditions")
    pp = pdir / "panel.parquet"
    run = pdir / "stage_d" / "STAGED_T_001"
    good = pd.read_parquet(run / "preds.parquet")
    bad = good.copy()
    bad["outcome"] = bad["outcome"] + 0.01
    bad.to_parquet(run / "preds.parquet", index=False)
    try:
        man, sha = SB.load_manifest()
        quiet(SF.run_forensics, pp, root, run, TARGETS, SF.load_isin_files([str(ip)]), verbose=False)
        check(False, "outcomes that no longer match the cache stop the tool")
    except SF.IntegrityError as e:
        check("no longer matches" in str(e), "outcomes that no longer match the cache stop the tool (IntegrityError)")
    finally:
        good.to_parquet(run / "preds.parquet", index=False)
    try:
        quiet(SF.main, ["--panel", str(pdir), "--root", str(root), "--isin", str(tmp / "nope.csv"),
                        "--rerun-reason", "t"])
        check(False, "a missing ISIN file is refused")
    except SystemExit as e:
        check("not found" in str(e), "a missing ISIN file is refused")
    orig = SF.CFG
    try:
        SF.CFG = dict(orig, lock_search_sessions=5)
        try:
            SF.load_declaration()
            check(False, "a setting that differs from the declaration is refused")
        except SystemExit as e:
            check("lock_search_sessions" in str(e), "a setting that differs from the declaration is refused")
    finally:
        SF.CFG = orig
    t2 = tmp / "empty"
    t2.mkdir()
    shutil.copy(pp, t2 / "panel.parquet")
    try:
        SF.find_run(t2 / "panel.parquet", None)
        check(False, "no stage-D run on record is refused")
    except SystemExit as e:
        check("no stage-D run" in str(e), "no stage-D run on record is refused")


def main():
    test_origin()
    test_ticks()
    test_rescore()
    tmp = Path(tempfile.mkdtemp())
    try:
        test_isin(tmp)
        root, pdir, ip = test_world(tmp)
        test_stops(tmp, root, pdir, ip)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print()
    if FAILS:
        print(f"FAILED  {len(FAILS)} check(s):")
        for f in FAILS:
            print("   - " + f)
        return 1
    print(f"VERIFIED  {SF.CODE_VERSION}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
